document.addEventListener('DOMContentLoaded', function () {
  // Footer year
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Mobile nav toggle
  var burger = document.querySelector('.burger');
  var tabs = document.querySelector('nav.tabs');
  if (burger && tabs) {
    burger.addEventListener('click', function () {
      tabs.classList.toggle('open');
    });
  }

  // Active nav link based on current page
  var current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav.tabs a').forEach(function (link) {
    var href = link.getAttribute('href');
    if (href === current) link.classList.add('active');
  });

  // Redaction reveal (case studies page)
  document.querySelectorAll('.redact').forEach(function (el) {
    function toggle() { el.classList.toggle('open'); }
    el.addEventListener('click', toggle);
    el.addEventListener('keypress', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
  });

  // Contact form -> mailto (static site, no backend)
  var form = document.getElementById('caseForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = document.getElementById('name').value;
      var org = document.getElementById('org').value;
      var type = document.getElementById('type').value;
      var details = document.getElementById('details').value;
      var subject = encodeURIComponent('New Enquiry: ' + type);
      var body = encodeURIComponent(
        'Name: ' + name + '\n' +
        'Organisation: ' + (org || '-') + '\n' +
        'Nature of enquiry: ' + type + '\n\n' +
        'Details:\n' + details
      );
      window.location.href = 'mailto:omacinvestigations@gmail.com?subject=' + subject + '&body=' + body;
      var status = document.getElementById('formStatus');
      if (status) status.textContent = 'Opening your email client…';
    });
  }
});
